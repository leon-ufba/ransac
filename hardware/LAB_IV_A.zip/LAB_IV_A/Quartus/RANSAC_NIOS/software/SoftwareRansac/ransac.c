#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdint.h>

#include "ransac.h"

typedef struct {
  float x;
  float y;
} Point;

typedef struct {
  float a;
  float b;
} Line;

typedef struct {
    Line bestModel;
    float bestFit;
    int bestQty;
} RansacResult;

// RANSAC parameters
#define MIN_POINTS 2        // - The minimum number of data points required to estimate the model parameters.
#define C 0.5              // - The percent of close data points (inliers) required to assert that the model fits well to the data.
#define E 2               // - A threshold value to determine data points that are fit well by the model (inlier).
#define N 10                // - Number of iterations required
#define MIN_DIST_POINTS 10  // - The minimum points distance required to select the sample

#define POINT_SIZE sizeof(Point)*2

/**void readStructFromMemory(Point* structPtr, uint32_t position) {
    // Ponteiro para o endere�o de mem�ria externa
    volatile int* memoryPtr = (volatile uint32_t*)END_BASE_DATA_X+ 2*position;

    // Realiza a leitura dos dados da mem�ria externa
    structPtr->x = *((uint32_t*)memoryPtr);
    memoryPtr++;
    structPtr->y = *((uint32_t*)memoryPtr);
    memoryPtr += 2;
}
**/

Line leastSquare(Point* p, Point* q, int size) {
	float sx = 0;
	float sy = 0;
	float sxy = 0;
	float sx2 = 0;
	if (size == 0) {
		Line line = {INFINITY, 0};
		return line;
	}

	sx = p->x + q->x;
	sy = p->y + q->y;
	sxy = (p->x + q->x) * (p->y + q->y);
	sx2 = (p->x + q->x) * (p->x + q->x);

	float avg_y = sy / size;
	float den = (size * sx2 - sx * sx);
	if (den == 0) {
		Line line = {INFINITY, avg_y};
		return line;
	}
	float a = (size * sxy - sx * sy) / den;
	float b = (sy / size) - a * (sx / size);
	Line line = {a, b};
	return line;
	}

float coefficientOfDetermination(int* dataX, int* dataY, Line model, float avg_y, int data_size) {
    float ss_res = 0;
    float ss_tot = 0;
    for (int i = 0; i < data_size; i++) {
        float f = model.a * dataX[i] + model.b;
        float y_f = (dataY[i] - f);
        float y_y = (dataY[i] - avg_y);
        ss_res += y_f * y_f;
        ss_tot += y_y * y_y;
    }
    float r = (ss_res / ss_tot);
    return r;
}

void inliersOutliers(int* dataX, int* dataY, Line model, int dataSize, int* inlierSize, int* outlierSize) {

    float square2 = E * E * (model.a * model.a + 1.0);
    for (int k = 0; k < dataSize; k++) {
        float dist = (model.a * dataX[k] - dataY[k] + model.b);
        if (dist * dist <= square2) {
        	inliers_X[*inlierSize] = dataX[k];
        	inliers_X[*inlierSize] = dataY[k];
            (*inlierSize)++;
        } else {
        	outliers_X[*outlierSize] = dataX[k];
        	outliers_Y[*outlierSize] = dataY[k];
            (*outlierSize)++;
        }
    }
}

void checkModel(int* dataX, int* dataY, Point* a, Point* b, RansacResult* rs, int data_size, int temp_size) {

	int inlinersSize = 0;
	int outlierSize = 0;
	Line model = leastSquare(a, b, temp_size);

	inliersOutliers(dataX, dataY, model, data_size, &inlinersSize, &outlierSize);

	if(inlinersSize >= rs->bestQty && inlinersSize >= (int)(data_size * C)){
		Line inliersModel = leastSquare(a, b, inlinersSize);
		float inliersAvg_y = 0;
		for (int i = 0; i < inlinersSize; i++) {
			inliersAvg_y += inliers_Y[i];
		}
		inliersAvg_y /= inlinersSize;
		float  inliersFit = coefficientOfDetermination(inliers_X, inliers_Y, inliersModel, inliersAvg_y, data_size);
		if (inliersFit < rs->bestFit) {
		rs->bestModel = inliersModel;
		rs->bestFit = inliersFit;
		rs->bestQty = inlinersSize;
        }
    }
}
float squareDistanceBetweenPoints (Point* a, Point* b){
    int dx = a->x - b->x;
    int dy = a->y - b->y;
    return (dx * dx) + (dy * dy);
}

RansacResult RANSAC(Point* botPos, int data_size) {
    RansacResult rs;

    rs.bestModel.a = 0.0;
    rs.bestModel.b = botPos->y;
    rs.bestFit = INFINITY;
    rs.bestQty = 0;

    int temp_dist_points = 0;
    int temp_index = 0;

    int loopCounter= 0;
    int inlinersSize = 0;
    int outlierSize = 0;

    inliersOutliers(data_X, data_Y, rs.bestModel, data_size, &inlinersSize, &outlierSize);

    if (outlierSize == 0) {
        rs.bestFit = INFINITY;
        rs.bestQty = data_size;
        return rs;
    }
    int temp_size = MIN_POINTS;

    //Posi��o inicial do rob�
    Point start;
    start.x = outliers_X[outlierSize];
    start.y = outliers_Y[outlierSize];
    Point temp;
    //Execute for N iterations
    while(loopCounter < N) {
        //Sorteia 2 coordenadas que tenham uma dist�ncia minima entre si
        if(temp_dist_points < MIN_DIST_POINTS) {
        for (int j = 1; j < temp_size; j++) {
            temp_index = rand()%outlierSize;
            temp.x = outliers_X[temp_index];
            temp.y = outliers_Y[temp_index];
            temp_dist_points = squareDistanceBetweenPoints(&temp, &start);
        }
        }
        else {
            checkModel(outliers_X, outliers_Y, &temp, &start, &rs, outlierSize, temp_size);
            temp_dist_points = 0;
            loopCounter++;
        }
    }

    return rs;
}
