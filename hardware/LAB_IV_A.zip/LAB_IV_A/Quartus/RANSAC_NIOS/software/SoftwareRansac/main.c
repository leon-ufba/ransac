#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ransac.c"
#include "ransac.h"



Point calculateIntersection(Line* k, Line* l) {
    Point intersection;
    intersection.x = (l->b - k->b) / (k->a - l->a);
    intersection.y = k->a * intersection.x + k->b;
    return intersection;
}

float getAngleFromModel(float a) {
    float radian = atan(a);
    return radian;
}

int main() {
    /***Point begin;
    //Point StepXY;
    Point data[MAX_POINTS];
    Point outliers[MAX_POINTS];
    RansacResult model;
    ***/
    int data_size = size;

    int j = 0;
    for (int i = 0; i<=data_size; i+=1) {
    	data_X[i] = coords[X];
    	data_Y[i] = coords[Y];
    	controle[0] = j;
    	j+=2;
    }

    controle[0] = 1;
    if(data_size > MAX_POINTS) data_size = MAX_POINTS;

    // ------------ Calcula primeiro modelo de linha ------------//
    //Posicao inical do robo
    Point start;
    start.x = 0;
    start.y = 25;
    controle[0] = 2;
    RansacResult model;
    Line reference;
	reference.a = 0;
	reference.a = 25;

    model = RANSAC(&start, data_size);

    // ------------ Variaveis para resultado final -------------//
    Point intersection = { 0.0, 0.0 };
    int distance = 0;
    float angle = 0.0;

	if  (model.bestModel.a == 0.0){
		distance = data_X[data_size];
	}
	else
	{
		intersection = calculateIntersection(&model.bestModel,  &reference);
		distance = squareDistanceBetweenPoints(&intersection, &start);
		angle = getAngleFromModel (model.bestModel.a);
	}

	int *store_distance= END_BASE_DISTANCE;
	int *store_angle = END_BASE_ANGLE;

	controle[0] = 3;
	store_distance[0] = 0;
	store_angle[0] = 0;
	store_distance[0] = distance;
	store_angle[0] = angle;

    printf("\n--------Result----------\n");
    printf("intersection point:\t%f\t%f\n", intersection.x, intersection.y);
    printf("square distance:\t%d\n", distance);
    printf("angle: \t%f\n", angle);
    printf("\n");

    printf("\n-------------------------------------------------------------\n");
    printf("bestFit: %f\n", model.bestFit);
    printf("bestQty: %d\n", model.bestQty);
    printf("bestModel: %f\t%f\n", model.bestModel.a, model.bestModel.b );


    return 0;
}
