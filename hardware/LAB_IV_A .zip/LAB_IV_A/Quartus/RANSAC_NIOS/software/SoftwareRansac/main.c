#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ransac.c"
#include "ransac.h"

#define END_BASE_MEMO (int *) 0x0000

Point calculateIntersection(Line* k, Line* l) {
    Point intersection;
    intersection.x = (l->b - k->b) / (k->a - l->a);
    intersection.y = k->a * intersection.x + k->b;
    return intersection;
}

//float radianToDegree(float radian) {
//   return radian * 180.0 / PI;
//}

float getAngleFromModel(float a) {
    float radian = atan(a);
    //float degree = radianToDegree(radian);
    return radian;
}

int main() {
    /***Point begin;
    //Point StepXY;
    Point data[MAX_POINTS];
    Point outliers[MAX_POINTS];
    RansacResult models[2];
    ***/
    int data_size;
    //int step;
    int *teste = END_BASE_MEMO;

    data_size = 153;
    int data_size_coord = data_size*2;

    for (int i = 0; i<(data_size_coord); i++) {
    	teste[i] = coords[i];
    }


    teste[data_size_coord] = teste[0] + teste[1];

    float soma = teste[data_size_coord];

    printf("Resultado: %f\n", soma);

    /***
    if(data_size > MAX_POINTS) data_size = MAX_POINTS;

    // ------------ Calcula primeiro modelo de linha ------------//
    //Posicao inical do robo
    begin.x = 0;
    begin.y = 25;
    models[0] = RANSAC(&begin, data, outliers, data_size);
    int inliers_size = models[0].bestQty;
    int outliers_size = (int)(data_size-inliers_size);

    // -------- Variaveis para segundo modelo de linha ---------//
    Point beginSecond = outliers[0];

    // ------------ Variaveis para resultado final -------------//
    Point intersection = { 0.0, 0.0 };
    float distance = 0.0;
    float angle = 0.0;

    // ---- Condicao para conjunto de pontos com modelo unico ----//
    if (outliers_size <= 10) distance = data[data_size-1].x - begin.x;
    // ---- Condicao para calcular segundo modelo de linha ----//
    else {

     models[1] = RANSAC(&beginSecond, outliers, outliers, outliers_size);

        if  ((models[1].bestModel.a != 0.0) & (models[1].bestModel.b != 0.0)) {
            intersection = calculateIntersection(&models[0].bestModel,  &models[1].bestModel);
            distance = squareDistanceBetweenPoints(&intersection, &begin);
            angle = getAngleFromModel (models[1].bestModel.a);
        }

    }

    printf("\n--------Result----------\n");
    printf("intersection point:\t%f\t%f\n", intersection.x, intersection.y);
    printf("square distance:\t%f\n", distance);
    printf("angle: \t%f\n", angle);
    printf("\n");

    printf("\n-------------------------------------------------------------\n");
    printf("bestFit: %f\n", models[0].bestFit);
    printf("bestQty: %d\n", models[0].bestQty);
    printf("bestModel: %f\t%f\n", models[0].bestModel.a, models[0].bestModel.b );
    printf("\n----------------------\n");
    printf("bestFit: %f\n", models[1].bestFit);
    printf("bestQty: %d\n", models[1].bestQty);
    printf("bestModel: %f\t%f\n", models[1].bestModel.a, models[1].bestModel.b );
	***/
    return 0;
}
